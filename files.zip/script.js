/* ============================================================
   AURUM CLUB — game logic
   All currency below is virtual play-money only. Nothing here
   ever connects to a payment processor, and no winnings can be
   withdrawn, transferred, or redeemed for anything of value.
   ============================================================ */

const STARTING_BALANCE = 1000;
const BALANCE_KEY = 'aurum_club_balance';

function getBalance(){
  const v = localStorage.getItem(BALANCE_KEY);
  return v === null ? STARTING_BALANCE : parseInt(v, 10);
}
function setBalance(v){
  const clamped = Math.max(0, v);
  localStorage.setItem(BALANCE_KEY, String(clamped));
  document.querySelectorAll('.js-balance').forEach(el => {
    el.textContent = clamped.toLocaleString();
  });
  return clamped;
}
function adjustBalance(delta){
  return setBalance(getBalance() + delta);
}
function refillIfEmpty(){
  if (getBalance() <= 0){
    setBalance(STARTING_BALANCE);
    return true;
  }
  return false;
}

document.addEventListener('DOMContentLoaded', () => {
  setBalance(getBalance());

  /* ---------------- tabs ---------------- */
  const tabButtons = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.game-panel');
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => b.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.target).classList.add('active');
    });
  });

  /* ================= SLOT MACHINE ================= */
  const SYMBOLS = ['🍒','🍋','🔔','⭐','💎','7️⃣'];
  const PAYOUTS = { '🍒':2, '🍋':3, '🔔':5, '⭐':8, '💎':15, '7️⃣':25 };
  const reels = document.querySelectorAll('.reel');
  const spinBtn = document.getElementById('spin-btn');
  const slotBet = document.getElementById('slot-bet');
  const slotResult = document.getElementById('slot-result');

  function randomSymbol(){ return SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]; }

  if (spinBtn){
    spinBtn.addEventListener('click', () => {
      const bet = parseInt(slotBet.value, 10) || 10;
      if (getBalance() < bet){
        slotResult.textContent = "Not enough coins for that bet.";
        return;
      }
      adjustBalance(-bet);
      spinBtn.disabled = true;
      reels.forEach(r => r.classList.add('spinning'));
      slotResult.textContent = 'Spinning…';

      const finalSymbols = [randomSymbol(), randomSymbol(), randomSymbol()];
      const spinDuration = [900, 1200, 1500];

      reels.forEach((reel, i) => {
        let ticks = 0;
        const flicker = setInterval(() => { reel.textContent = randomSymbol(); ticks++; }, 70);
        setTimeout(() => {
          clearInterval(flicker);
          reel.textContent = finalSymbols[i];
          reel.classList.remove('spinning');
          if (i === reels.length - 1){
            settleSlot(finalSymbols, bet);
            spinBtn.disabled = false;
          }
        }, spinDuration[i]);
      });
    });
  }

  function settleSlot(symbols, bet){
    const [a,b,c] = symbols;
    let payout = 0;
    if (a === b && b === c){
      payout = bet * PAYOUTS[a];
      slotResult.textContent = `Jackpot! ${a}${b}${c} pays ${payout} coins.`;
    } else if (a === b || b === c || a === c){
      payout = Math.round(bet * 1.5);
      slotResult.textContent = `Pair match — you win ${payout} coins.`;
    } else {
      slotResult.textContent = `No match. Try again!`;
    }
    if (payout > 0) adjustBalance(payout);
    refillIfEmpty();
  }

  /* ================= DICE ================= */
  const rollBtn = document.getElementById('roll-btn');
  const diceBet = document.getElementById('dice-bet');
  const diceGuess = document.getElementById('dice-guess');
  const diceResult = document.getElementById('dice-result');
  const dieEls = document.querySelectorAll('.die');

  const PIP_LAYOUTS = {
    1: [4],
    2: [0,8],
    3: [0,4,8],
    4: [0,2,6,8],
    5: [0,2,4,6,8],
    6: [0,2,3,5,6,8]
  };
  function renderDie(el, value){
    el.innerHTML = '';
    for (let i=0;i<9;i++){
      const p = document.createElement('div');
      p.className = 'pip' + (PIP_LAYOUTS[value].includes(i) ? ' on' : '');
      el.appendChild(p);
    }
  }
  dieEls.forEach(el => renderDie(el, 1));

  if (rollBtn){
    rollBtn.addEventListener('click', () => {
      const bet = parseInt(diceBet.value, 10) || 10;
      if (getBalance() < bet){
        diceResult.textContent = "Not enough coins for that bet.";
        return;
      }
      adjustBalance(-bet);
      rollBtn.disabled = true;
      dieEls.forEach(el => el.classList.add('rolling'));
      diceResult.textContent = 'Rolling…';

      setTimeout(() => {
        const d1 = 1 + Math.floor(Math.random()*6);
        const d2 = 1 + Math.floor(Math.random()*6);
        const total = d1 + d2;
        renderDie(dieEls[0], d1);
        renderDie(dieEls[1], d2);
        dieEls.forEach(el => el.classList.remove('rolling'));

        const guess = diceGuess.value; // 'low' (2-6), 'seven' (7), 'high' (8-12)
        let win = false, payout = 0;
        if (guess === 'low' && total <= 6){ win = true; payout = bet * 2; }
        if (guess === 'high' && total >= 8){ win = true; payout = bet * 2; }
        if (guess === 'seven' && total === 7){ win = true; payout = bet * 5; }

        if (win){
          adjustBalance(payout);
          diceResult.textContent = `Rolled ${d1} + ${d2} = ${total}. You win ${payout} coins!`;
        } else {
          diceResult.textContent = `Rolled ${d1} + ${d2} = ${total}. No win this time.`;
        }
        refillIfEmpty();
        rollBtn.disabled = false;
      }, 650);
    });
  }

  /* ================= ROULETTE ================= */
  const wheel = document.getElementById('roulette-wheel');
  const spinWheelBtn = document.getElementById('roulette-spin-btn');
  const rouletteBet = document.getElementById('roulette-bet');
  const rouletteResult = document.getElementById('roulette-result');
  const chips = document.querySelectorAll('.chip[data-choice]');
  let currentChoice = 'red';

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('selected'));
      chip.classList.add('selected');
      currentChoice = chip.dataset.choice;
    });
  });

  // 18 red / 18 black / 1 green(0), simplified into 12 wedges for the visual wheel
  const WEDGE_COLORS = ['red','black','red','black','red','black','red','black','red','black','red','green'];
  let wheelRotation = 0;

  function buildWheelGradient(){
    const step = 360 / WEDGE_COLORS.length;
    const stops = WEDGE_COLORS.map((c, i) => {
      const color = c === 'red' ? '#7A1F2B' : c === 'black' ? '#141414' : '#1E6B44';
      return `${color} ${i*step}deg ${(i+1)*step}deg`;
    }).join(', ');
    if (wheel) wheel.style.background = `conic-gradient(${stops})`;
  }
  buildWheelGradient();

  if (spinWheelBtn){
    spinWheelBtn.addEventListener('click', () => {
      const bet = parseInt(rouletteBet.value, 10) || 10;
      if (getBalance() < bet){
        rouletteResult.textContent = "Not enough coins for that bet.";
        return;
      }
      adjustBalance(-bet);
      spinWheelBtn.disabled = true;
      rouletteResult.textContent = 'Spinning…';

      const wedgeIndex = Math.floor(Math.random() * WEDGE_COLORS.length);
      const landedColor = WEDGE_COLORS[wedgeIndex];
      const step = 360 / WEDGE_COLORS.length;
      const targetAngle = 360 * 5 + (wedgeIndex * step) + step/2;
      wheelRotation = targetAngle;
      wheel.style.transform = `rotate(${wheelRotation}deg)`;

      setTimeout(() => {
        let payout = 0;
        if (currentChoice === landedColor && landedColor !== 'green'){
          payout = bet * 2;
        } else if (currentChoice === 'green' && landedColor === 'green'){
          payout = bet * 14;
        }
        if (payout > 0){
          adjustBalance(payout);
          rouletteResult.textContent = `Ball landed on ${landedColor.toUpperCase()}. You win ${payout} coins!`;
        } else {
          rouletteResult.textContent = `Ball landed on ${landedColor.toUpperCase()}. No win this time.`;
        }
        refillIfEmpty();
        spinWheelBtn.disabled = false;
      }, 3500);
    });
  }

  /* ---------- reset balance control (if present) ---------- */
  const resetBtn = document.getElementById('reset-balance');
  if (resetBtn){
    resetBtn.addEventListener('click', () => {
      setBalance(STARTING_BALANCE);
    });
  }
});
